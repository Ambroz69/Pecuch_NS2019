/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package undersampling;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 *
 * @author Dominik
 */
public class Undersampling {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         try {
            String strLine;
            int counter = 0;
            boolean first = true;
            FileInputStream fstream = new FileInputStream("imdb_2.csv");
            BufferedReader br = new BufferedReader(new InputStreamReader(fstream)); 
            PrintWriter out = new PrintWriter("imdb_3.csv");

            //filtrovanie pripon a error kodov 
            while ((strLine = br.readLine()) != null) {
                
                String temp[] = {};
                temp = strLine.split(";");
                        
                if (first) {
                    out.println(strLine);
                    first = false;
                } else {
                    if (temp[7].equals("0")) {
                        counter++;
                    } else {
                        out.println(strLine);
                    }
                }
                
                if (counter == 30) {
                    out.println(strLine);
                    counter = 0;
                }
                        
            }
            fstream.close();
            out.close();
         } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
    
}
